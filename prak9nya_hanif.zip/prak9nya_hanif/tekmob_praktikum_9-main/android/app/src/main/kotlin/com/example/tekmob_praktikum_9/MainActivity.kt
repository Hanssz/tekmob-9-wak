package com.example.tekmob_praktikum_9

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
